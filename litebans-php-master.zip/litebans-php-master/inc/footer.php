<script src="<?php echo $this->autoversion('inc/js/jquery-3.3.1.min.js'); ?>"></script>
<script src="<?php echo $this->autoversion('inc/js/bootstrap.min.js'); ?>"></script>
<?php echo "</html>"; ?>
